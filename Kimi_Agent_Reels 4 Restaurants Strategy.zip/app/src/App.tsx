import Navigation from './sections/Navigation';
import Hero from './sections/Hero';
import SocialProof from './sections/SocialProof';
import Problem from './sections/Problem';
import Solution from './sections/Solution';
import Portfolio from './sections/Portfolio';
import Packages from './sections/Packages';
import Process from './sections/Process';
import Testimonials from './sections/Testimonials';
import FAQ from './sections/FAQ';
import Contact from './sections/Contact';
import Footer from './sections/Footer';

function App() {
  return (
    <div className="min-h-screen bg-white">
      <Navigation />
      <main>
        <Hero />
        <SocialProof />
        <Problem />
        <Solution />
        <Portfolio />
        <Packages />
        <Process />
        <Testimonials />
        <FAQ />
        <Contact />
      </main>
      <Footer />
    </div>
  );
}

export default App;
